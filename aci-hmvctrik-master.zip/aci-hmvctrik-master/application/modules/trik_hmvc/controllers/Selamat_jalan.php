<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Selamat_jalan extends MX_Controller {
	
	public function index() {
		
		$this->load->view('v_selamat_jalan');
		
	}

}

/* End of file selamat_datang.php */
/* Location: ./application/modules/trik_hmvc/controllers/Selamat_jalan.php */