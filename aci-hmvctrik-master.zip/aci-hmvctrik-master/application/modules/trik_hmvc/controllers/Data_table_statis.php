<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Data_table_statis extends MX_Controller {
	
	public function index() {
		
		$this->load->view('v_data_table_statis');
		
	}

}

/* End of file selamat_datang.php */
/* Location: ./application/modules/trik_hmvc/controllers/Data_table.php */